package com.example.mectow_mechanic.ui.profile;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import com.example.mectow_mechanic.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.StorageReference;


public class ProfileFragment extends Fragment {
    private ProfileViewModel profileViewModel;
    private ImageView updateimg;
    private TextView update_name, updateemail, updatephonenumber;
    private Button updatebtn;
    private String uid;
    private static final String Mechanic = "mechanic";
    FirebaseAuth auth;
    //    private final int REQ=1;
//    private Bitmap bitmap=null;
    private StorageReference storageReference;
    private FirebaseDatabase database;
    private DatabaseReference reference;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        profileViewModel =
                ViewModelProviders.of(this).get(ProfileViewModel.class);
        View root = inflater.inflate(R.layout.fragment_nav_profile, container, false);
        update_name = (TextView)root.findViewById(R.id.updatename);
        updateemail =(TextView)root.findViewById(R.id.updateemail);
        updatephonenumber = (TextView)root.findViewById(R.id.updatephonenumber);

        // updatebtn=findViewById(R.id.updatebtn);
        auth=FirebaseAuth.getInstance();
        uid=auth.getUid();
        database = FirebaseDatabase.getInstance();
        reference = database.getReference("Mechanic").child(uid);
        reference.addValueEventListener(new ValueEventListener() {

            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                update_name.setText(snapshot.child("name").getValue(String.class));
                String email=auth.getCurrentUser().getEmail();
                updateemail.setText(email);
                updatephonenumber.setText(snapshot.child("phone_number").getValue(String.class));

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
            }
        });
        //final TextView textView = root.findViewById(R.id.text_profile);
        profileViewModel.getText().observe(getViewLifecycleOwner(), new Observer<String>() {
            @Override
            public void onChanged(@Nullable String s) {
               // textView.setText(s);
            }
        });
        return root;
    }
}
